import style from "./forgot-password.module.css";
import {
  Button,
  Input,
} from "@ya.praktikum/react-developer-burger-ui-components";
import { Link } from "react-router-dom";

export const ForgotBlock = () => {
  return (
    <div className={style.inner}>
      <p className="text text_type_main-medium mb-6">Восстановление пароля</p>
      <div className={style.inputs}>
        <div className="mb-6">
          <Input
            type={"email"}
            placeholder={"Укажите e-mail"}
            name={"name"}
            value={""}
            error={false}
            errorText={"Ошибка"}
            size={"default"}
            onChange={() => {}}
          />
        </div>
      </div>
      <div className="mb-20">
        <Button type="primary" size="medium">
          Восстановить
        </Button>
      </div>
      <div>
        <p className="text text_type_main-default">
          Вспомнили пароль?
          <Link className={style.link} to="/login">
            Войти
          </Link>
        </p>
      </div>
    </div>
  );
};
