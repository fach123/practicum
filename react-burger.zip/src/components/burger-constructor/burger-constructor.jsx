import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  ConstructorElement,
  Button,
  DragIcon,
  CurrencyIcon,
} from "@ya.praktikum/react-developer-burger-ui-components";
import style from "./burger-constructor.module.css";
import OrderDetails from "../order-details/order-details";
import Modal from "../modal/modal";
import { useSelector } from "react-redux";
import { useDrop } from "react-dnd";

const BurgerConstructor = (props) => {
  const [openModal, setOpenModal] = useState(false);
  const { items } = useSelector((store) => store.api);
  const [{ handlerId, isOver }, drop] = useDrop(() => ({
    accept: ["SORT_INGREDIENT", "NEW_INGREDIENT"],
    drop: (itemId) => {},
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  }));
  return (
    <div className={style.inner}>
      <div ref={drop} className={`${style.editor} mt-25`}>
        <div className="mr-4">
          <ConstructorElement
            type="top"
            isLocked={true}
            text="Выберите Булки"
            thumbnail="null"
          />
        </div>

        <div className={`${style.inner_child} custom-scroll pr-2`}>
          {items
            .filter((el) => el.type !== "bun")
            .map((el, i) => (
              <div className={style.item} key={i}>
                <span className="mr-3">
                  <DragIcon type="primary" />
                </span>
                <ConstructorElement
                  text={el.name}
                  price={el.price}
                  thumbnail={el.image_mobile}
                />
              </div>
            ))}
        </div>

        <div className="mr-4">
          <ConstructorElement type="bottom" isLocked={true} text="булки" />
        </div>
      </div>
      <div className={`${style.order} mt-10`}>
        <div className={`mr-10`}>
          <span className="text text_type_digits-medium mr-1">123</span>
          <CurrencyIcon type="primary" />
        </div>
        <Button type="primary" size="large" onClick={() => setOpenModal(true)}>
          Оформить заказ
        </Button>
      </div>
      {openModal && (
        <Modal setOpenModal={setOpenModal} title="">
          <OrderDetails />
        </Modal>
      )}
    </div>
  );
};

BurgerConstructor.propTypes = {
  setOpenModal: PropTypes.func,
  openModal: PropTypes.object,
};
export default BurgerConstructor;
