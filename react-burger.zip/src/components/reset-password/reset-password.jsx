import style from "./reset-password.module.css";
import {
  Button,
  Input,
} from "@ya.praktikum/react-developer-burger-ui-components";
import { Link } from "react-router-dom";

export const ResetBlock = () => {
  return (
    <div className={style.inner}>
      <p className="text text_type_main-medium mb-6">Восстановление пароля</p>
      <div className={style.inputs}>
        <div className="mb-6">
          <Input
            type={"password"}
            placeholder={"Введите новый пароль"}
            name={"name"}
            value={""}
            error={false}
            errorText={"Ошибка"}
            size={"default"}
            onChange={() => {}}
            icon={"ShowIcon"}
          />
        </div>
        <div className="mb-6">
          <Input
            type={"text"}
            placeholder={"Введите код из письма"}
            name={"name"}
            value={""}
            error={false}
            errorText={"Ошибка"}
            size={"default"}
            onChange={() => {}}
          />
        </div>
      </div>
      <div className="mb-20">
        <Button type="primary" size="medium">
          Сохранить
        </Button>
      </div>
      <div>
        <p className="text text_type_main-default">
          Вспомнили пароль?
          <Link className={style.link} to="/login">
            Войти
          </Link>
        </p>
      </div>
    </div>
  );
};
