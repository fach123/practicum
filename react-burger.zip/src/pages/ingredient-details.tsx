import { IngredientDetails } from "../components/ingredient-details/ingredient-details";
export function IngredientDetailsPage() {
  return <IngredientDetails />;
}
