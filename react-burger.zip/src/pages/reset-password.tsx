import { ResetBlock } from "../components/reset-password/reset-password";
export function ResetPasswordPage() {
  return <ResetBlock />;
}
