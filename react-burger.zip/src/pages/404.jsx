export function NotFound404() {
  return (
    <div className="mt-30" style={{ textAlign: "center" }}>
      <p className="text text_type_main-large">404</p>
    </div>
  );
}
