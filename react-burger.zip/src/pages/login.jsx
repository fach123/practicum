import { LoginBlock } from "../components/login/login";
export function LoginPage() {
  return <LoginBlock />;
}
