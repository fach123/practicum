import { FeedBlock } from "../components/feed/feed";
export function FeedPage() {
    return <FeedBlock />;
}
