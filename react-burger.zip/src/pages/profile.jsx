import { ProfileBlock } from "../components/profile/profile";
export function ProfilePage() {
  return <ProfileBlock />;
}
