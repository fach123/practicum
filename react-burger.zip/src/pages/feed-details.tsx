import { FeedDetails } from "../components/feed/feed-details";
export function FeedDetailsPage() {
    return <FeedDetails />;
}
