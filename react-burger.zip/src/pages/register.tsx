import { RegisterBlock } from "../components/register/register";
export function RegisterPage() {
  return <RegisterBlock />;
}
