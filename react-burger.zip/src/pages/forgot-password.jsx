import { ForgotBlock } from "../components/forgot-password/forgot-password";
export function ForgotPasswordPage() {
  return <ForgotBlock />;
}
