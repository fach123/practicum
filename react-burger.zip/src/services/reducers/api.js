import { getIngredients, sendOrder, goRegister, goLogin } from "../actions/api";
import { createReducer } from "@reduxjs/toolkit";

const user = JSON.parse(localStorage.getItem("user"));

const initialState = {
  user: user ? user : {},

  items: [],
  itemsRequest: false,
  itemsFailed: false,

  orderItems: {},
  orderItemsRequest: false,
  orderItemsFailed: false,

  registerRequest: false,
  registerFailed: false,

  loginRequest: false,
  loginFailed: false,
};

export const apiReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(getIngredients.pending, (state, action) => {
      state.itemsRequest = true;
    })
    .addCase(getIngredients.rejected, (state, action) => {
      state.itemsRequest = false;
      state.itemsFailed = true;
    })
    .addCase(getIngredients.fulfilled, (state, action) => {
      state.itemsRequest = false;
      state.itemsFailed = false;
      state.items = action.payload;
    })
    .addCase(sendOrder.pending, (state, action) => {
      state.orderItemsRequest = true;
      state.orderItems = {};
    })
    .addCase(sendOrder.rejected, (state, action) => {
      state.orderItemsRequest = false;
      state.orderItemsFailed = true;
    })
    .addCase(sendOrder.fulfilled, (state, action) => {
      console.log(action);
      state.orderItemsRequest = false;
      state.orderItemsFailed = false;
      state.orderItems = action.payload;
    })
    .addCase(goRegister.pending, (state, action) => {
      state.registerRequest = true;
      state.orderItems = {};
    })
    .addCase(goRegister.rejected, (state, action) => {
      state.registerRequest = false;
      state.registerFailed = true;
    })
    .addCase(goRegister.fulfilled, (state, action) => {
      console.log(action);
      state.registerRequest = false;
      state.registerFailed = false;
      state.user = action.payload;
      localStorage.setItem("user", JSON.stringify(action.payload));
      /*localStorage.setItem("accessToken", action.payload.accessToken);
            localStorage.setItem("refreshToken", action.payload.refreshToken);*/
    })
    .addCase(goLogin.pending, (state, action) => {
      state.loginRequest = true;
      state.orderItems = {};
    })
    .addCase(goLogin.rejected, (state, action) => {
      state.loginRequest = false;
      state.loginFailed = true;
    })
    .addCase(goLogin.fulfilled, (state, action) => {
      console.log(action);
      state.loginRequest = false;
      state.loginFailed = false;
      state.user = action.payload;
      localStorage.setItem("user", JSON.stringify(action.payload));
      /*localStorage.setItem("accessToken", action.payload.accessToken);
            localStorage.setItem("refreshToken", action.payload.refreshToken);*/
    });
});
