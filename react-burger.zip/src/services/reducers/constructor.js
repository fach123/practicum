import {createReducer} from "@reduxjs/toolkit";
import {DROP_ITEM} from "../actions/constructor";

const initialState = {
    ingredients: [],
    bun: {},
    draggedIngredient: null
};

export const constructReducer = createReducer(initialState, (builder) => {
    builder
        .addCase(DROP_ITEM, (state, action) => {
            state.bun = action.item
        })
})