import { createAction } from "@reduxjs/toolkit";

export const SET_INFO = createAction("modal/set_info");
export const DELETE_INFO = createAction("modal/delete_info");
