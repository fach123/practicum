import {createAction} from "@reduxjs/toolkit";

export const DROP_ITEM = createAction('constructor/drop_item')